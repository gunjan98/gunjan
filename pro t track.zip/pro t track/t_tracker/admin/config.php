<?php 
if($conn = mysql_connect("localhost","root",""))
{
	if(!$db = mysql_select_db("proj_track",$conn))
	{
		echo mysql_error();
	}
session_start();	
}

?>
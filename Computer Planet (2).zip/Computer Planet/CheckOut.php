<?php
	include_once("Includes/Top.php");
	if(!isset($_SESSION['uid'])){
		header("location: Login.php");
	}else{
	header("location: Success.php");	
	}
?>
<form name="OrderForm" action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_ext-enter"><br>
<input type="hidden" name="redirect_cmd" value="_xclick"><br>
<input type="hidden" name="return"
value = "http://www.beautyshop.com/Success.php"><br>
<input type="hidden" name="cancel_return"
value = "http://www.beautyshop.com/Failure.php"><br>
<input type="hidden" name="business" value ="jaiswalsailesh@gmail.com">
<input type="hidden" name="item_name" value="BeautyShop">
<input type="hidden" name="shipping" value="5.00">
<input type="hidden" name="shipping2" value="5.00">
<input type="hidden" name="quantity" value="1"><br>
<input type="hidden" name="amount" value="<?=$_SESSION['netamt']?>"><br>
<input type="hidden" name="email" value="<?=$row[email]?>"><br>
<input type="hidden" name="first_name" value="<?=$row[firstname]?>"><br>
<input type="hidden" name="last_name" value="<?=$row[lastname]?>"><br>
<input type="hidden" name="address1"
value = "<?=$row[streetaddress1]?>"><br>
<input type="hidden" name="address2" value =
"<?=$row[streetaddress2]?>"><br>
<input type="hidden" name="city" value="<?=$row[city]?>"><br>
<input type="hidden" name="state" value="<?=$row[stateprov]?>"><br>
<input type="hidden" name="zip" value="<?=$row[pcode]?>"><br>
<input type="submit" name="Submit" value="Submit">
</form>
<?php
	include_once("Includes/Top.php");
?>

<title>Computer PLANET pvt ltd</title>
<img src="Images/cont2.jpg" width="280" height="340" align=right>
&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; 

<img src="Images/contactus1.jpg" width="600" height="200" align=left><br>
&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp;<img src="Images/logo.gif" width="400" height="200" align=middle><hr width=1050 size=1 color=blue align=left>



&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<font colour=blue size=4><u><b>HEAD office:</font></u></b><br><br>


<font color=rainbow size=2>Computer PLANET,Ram Nagar,<Roorkee><br>
Lane NO. 2,
Roorkee(U.K). INDIA.<br>

<img src="images/contact1.jpg" width="400" height="250"/><br>
<font color=blue size=3>
E-mail: <a href="mailto:pinju.kumari@gmail.com" >pinju.kumari@gmail.com</a></font>
<font color=green size=3> & ALSO...</font><img src="images/facebook.png"  width="200" height="150" align=center /><br>


<font color=black size=5>
<br><b><i> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
-:<u>Other Locations</u>:-</i></b></font><br>
<br>
&nbsp;&nbsp;&nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="location.html"><img src="images/indiamap.gif" width="700" height="500" align="center"/></a> 




 <?php
	include_once("Includes/Bottom.php");
?>



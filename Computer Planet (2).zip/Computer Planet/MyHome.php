<?php
	include_once("Includes/Top.php");	
?>
<font colour=blue size=5>Welcome to your Account.</font>
<?php
	include_once("Includes/Bottom.php");
?>
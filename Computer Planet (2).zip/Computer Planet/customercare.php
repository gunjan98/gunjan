<?php
	include_once("Includes/Top.php");
?>
<title>Computer PLANET pvt ltd.</title>
<br>
<font color=green size=5><b>Customer support Computer PLANET.</b></font><br>
<img src="Images/customerfirst.jpg" width="500" height="200" align=right>
<hr width=500 size=2 color=orange align=left>
<font color=purpal size=4 face=arial>
</br>

<br>
<font color=brown size=5>
<u>Quick and Easy ways to contact - We're Here to Help You!</u>.</font>
<br>
<br><br><font color=blue size=4>
<img src="Images/ccc1.jpg" width="100" height="80"align=left>
1.<b>Call the 24/7 Computer PLANET Customer Care Team</b>.
</font><h5>Our Customer Care is here for you 24 hours a day - 365 days a year at 040-4455918.</h5>

<a href="vote.php"><img src="images/ser2.png" alt="Header" width="400" height="250" align=Right /></a>


<font color=blue size=4>
<img src="Images/ccc3.gif" width="100" height="80"align=left>2.<b>Send as SMS -We will call you back provided you are not registered under DND*</b>.</font>
<h5>computer PLANET looks forward to helping you with your inquiry. We respond to SMSes in the order that<br>they are received, and we will respond to your email as quickly as possible. SMS HS18WEB to 51818 and we<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;will call you back.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*To check Your status call 08341925052 from your mobile.</h5>
<font color=blue size=4>
<img src="Images/chat.png" width="100" height="80"align=left>
3.<b>Computer PLANET Help Desk</b>.</font><h5>The fastest way to find answers to many questions is to Call us on +918341925052/+919059365991.</h5>
<font color=blue size=4><br>

<img src="Images/notes.jpg" width="100" height="100"align=left>
4.<b>Existing Order related Queries / Complaints</b>.</font><h5>The fastest way to find answers to many questions is to Call us on +918341925052/+919059365991.</h5><br>
<img src="Images/ccc2.jpg" width="350" height="200" align=right>

<font color=blue size=4>
<img src="Images/hh.gif" width="100" height="80"align=left>
5.<b>Do you have quality products? Partner with Us</b>.</font><h5>E-mail us your business profile and product catalog at partners@computerplanet.com and we will<br>get in touch with you soon.</h5>
<font color=blue size=4>
<img src="Images/bulk.gif" width="100" height="120"align=left>
6.<b>Bulk order enquiries</b>.</font><h5>We will get in touch with you and be able to better discuss your needs, any applicable discounts and<br>delivery options which you may require for all corporate gifting or bulk order enquiries. Please direct<br>your enquiries to us at at partners@computerplanet.com and we will get in touch with you soon.</h5>
<font color=blue size=4>
<img src="Images/ee.gif" width="90" height="100"align=left>
7.<b>General / Non Order Queries / Feedback</b>.</font><h5>Send your feedback on General / Non Order Queries / Feedback,mail us at enquiry@computerplanet.com</h5>


<br><br>

<br></br>

</font>




<?php
	include_once("Includes/Bottom.php");
?>

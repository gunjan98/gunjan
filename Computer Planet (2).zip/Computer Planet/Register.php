<?php
	include_once("Includes/Top.php");
	if(isset($_POST['Submit'])){
		$name = $_POST['Name'];
		$email = $_POST['EmailId'];
		$pwd  = md5($_POST['Password']);
                $addr =$_POST['Address'];
                $ph =$_POST['Contactno'];
		$date = time();
		$qry = "select * from bs_customers  ";
		$kk=1;
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
   echo '<font color=brown size=5>"That email is invalid");</font>';
 
	$kk=0;
}
if($ph=='')
{
	echo "<font color=brown size=5>Enter Phone no.</font><br/>";
	$kk=0;
}
		$sql = mysql_query($qry);
		
		
		while( $row = mysql_fetch_array($sql))
		{
			if($row['EmailId']==$email or $row['CONTACTNO']==$ph)
			{
						echo '<font color=brown size=5>"That Email id op Phone No is already registered");</font>';
						 $kk =0;				
			}
		}
		
		if($kk)
		{
		 $in = "INSERT INTO bs_customers(Name,EmailId,Password,Address,CONTACTNO,RegisteredOn) VALUES('$name', '$email', '$pwd','$addr',$ph,'$date')";
		mysql_query($in);
		
		$to = $email;
		$sub = "Email verification";
		$msg = "Dear $name,<br>
		Thank you for registering with our website. You can use our services after activating your account.";
		$msg .= "<br><br>To activate your account <a href='".SITEURL."/ActivateAccount.php?abc=$pwd'>click here</a>";
		$msg .= "<br><br>Thanks,<br>Admin<br>beautyshop.com";
		$header = "Content-type: text/html"."\r\n";
		$header .= "From: ".SENDER_ADDR."\r\n";
		@mail($to,$sub,$msg,$header);
		echo "<font color=brown size=5>Congratulations !! your Account has been Registered.</font>";
		
		//echo $msg;
		}
		else 
		{
			echo "<font color=brown size=5>Sorry !! your Account Can Not Registered.</font>";
		}
}
	
	
	
	
?>
     <title>Computer PLANET pvt ltd.</title>
    <table width="80%" border="0" cellspacing="1" cellpadding="2" align="center">
   
  <form name="RegisterForm" action="" method="post">
    <tr>
     <td colspan="2"><font color=green size=6>If you are returning user please login <a href="Login.php">here</a></font>
<img src="Images/ee1.gif" width="400" height="150" align="left"/>
</td>
  </tr>
  <tr>
    <td><font size=4>NAME</td>
    <td><input type="text" name="Name" required="required" class="inpbx"></font></td>
  </tr>
  <tr>
    <td><font size=4>Email-ID</td>
    <td><input type="email" name="EmailId" required="required"   class="inpbx"/></font></td>
  </tr>
  <tr>
    <td><font size=4>Password</td>
    <td><input type="password" name="Password" required="required"  class="inpbx"></font></td>
  </tr>
   <tr>
    <td><font size=4>Address</td>
    <td><input type="text" name="Address"  required="required"  class="inpbx"></font></td>
  </tr>
    <tr>
    <td><font size=4>Contact No</td>
    <td><input type="text" name="Contactno" required="required"  class="inpbx"></font></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="submit" name="Submit" value="REGISTER" class="btns"><input type="reset" name="reset" value="Reset" class="btns"></td>
  </tr>
  </form>
</table>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<br>
<br>
<br>
<br>
<br> 
<br>
<br>
<br>
<br>
<br>
<br>
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<img src="Images/free.jpg" width="1400" height="350" /><br>
<br>
<font size=2 color=black>Back to Homepage Click....</font><a href="http://localhost/Computer%20Planet/Computer%20Planet/index.php"><img src="Images/hh.jpg" width="120" height="100" title=Goback align=middle></a>
<?php
	include_once("Includes/Bottom.php");
?>
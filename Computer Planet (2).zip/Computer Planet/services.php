<?php
	include_once("Includes/Top.php");
?>
<title>Computer PLANET pvt ltd.</title>
<br>
<h2 style="text-align:center;"><img src="images/services.jpg" alt="Header" width="300" height="100"/></h2>
<hr width=1500 size=1 color=blue align=left><br>
&nbsp;&nbsp;<font color=blue size=4>SERVICES:-</font><font color=Black size=4>At Computer PLANET, we have experience in a variety of IT product and live projects for Industries and small scale business in the field of &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;IT,Banking, Retail, Telecom and FMCG.<br>

<br>

<font color=brown size=3>
<u>Our Services are as follows:</u>.</font>
<br><br><img src="Images/middle.gif" width="350" height="200" align=right>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="Images/bb.gif" width="30" height="15"> At Computerplanet.com we take pride in being able to offer you the lowest prices on computer parts 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
and systems as well as we provide software as a live project.<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="Images/bb.gif" width="30" height="15"> We provide the projects which  are developed by professional software developers/managers;<br> <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="Images/bb.gif" width="30" height="15"> It suits dedicated service providing model and grants deep intergation with your business
processes.<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="Images/bb.gif" width="30" height="15"> Over 50 successful large/middle projects sold.<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="Images/bb.gif" width="30" height="15"> Reduced service costs. The prices for our Computer comodities are relatively lower than in other dealers. Dedicated team Work has Provided &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;lower rates as compared to others.<br>
<img src="Images/ser1.jpg" width="350" height="330" align=right>
<img src="Images/border.gif" width="450" height="350">


<?php
	include_once("Includes/Bottom.php");
?>

<?php
	include_once("Includes/Top.php");
	$abc = $_GET['abc'];
	$up ="UPDATE bs_customers SET cStatus=1 WHERE Password ='$abc'";
	mysql_query($up);
	echo "Your account has been activated successfully";
?>
<?php
	include_once("Includes/Bottom.php");
?>
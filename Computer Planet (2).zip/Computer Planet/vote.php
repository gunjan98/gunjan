<?php
$str=file_get_contents("vote.txt");

$arr=explode("|",$str);
echo "<br>";
$v=$_GET['r'];
if(isset($_GET['sub']))
{
if($v=='y')
$arr[0]=$arr[0]+1;

else if($v=='n')
$arr[1]=$arr[1]+1;

else if($v=='d')
$arr[2]=$arr[2]+1;
}
$t=$arr[0]+$arr[1]+$arr[2];
$yes=$arr[0]/$t*100;
$no=$arr[1]/$t*100;
$dno=$arr[2]/$t*100;
$s=implode("|",$arr);
echo "<br>";

file_put_contents("vote.txt",$s);
?>
<title>Computer PLANET pvt ltd.</title>
<h1>
<img src="images/cust.jpg" width="450" height="230"/>
</h>
<h3>Customer satisfaction in business term, is playing a measure role,of how services provided by a company meet or surpass customer expectation.<br>It is seen as a key performance indicator within business.
In a competitive marketplace where businesses compete for customers,customer<br> satisfaction is seen as a key differentiator and increasingly has become a key element of business strategy.<br><font color=steel blue size=4 >So please give few second to vote:-</font></h3>
<h2><form>
<input type="radio" name="r" value="y"/>I am Very much Satisfied&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total=<?php echo " ",$arr[0];?><table><tr height=30><td bgcolor=green width='<?php echo $yes*4; ?>'></td><td bgcolor=gray width='<?php echo 400-($yes*4); ?>'></td></tr></table></h2>
<h2><input type="radio" name="r" value="n"/>I am Satisfied&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total=<?php echo " ",$arr[1];?>
<table><tr height=30><td bgcolor=blue width='<?php echo $no*4; ?>'></td><td bgcolor=gray width='<?php echo 400-($no*4); ?>'></td></tr></table></h2>
<h2><input type="radio" name="r" value="d"/>I am Unsatisfied&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total=<?php echo " ",$arr[2];?>
<table><tr height=30><td bgcolor=red width='<?php echo $dno*4; ?>'></td><td bgcolor=gray width='<?php echo 400-($dno*4); ?>'></td></tr></table></h2>
<input type="submit" name="sub" value="VOTE"/><h3><font color=blue>Back to Homepage Click...</font><a href="http://localhost/Computer%20Planet/Computer%20Planet/index.php"><img src="images/hh.jpg" alt="Header" width="100" height="90" /></a></h3>
</form>

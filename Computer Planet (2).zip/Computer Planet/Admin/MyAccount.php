<?php
	include_once("Includes/Top.php");
	$ack='';
	if($_SESSION['AdminId']=='')
	{
		echo '<script type="text/javascript">window.location.href ="index.php";</script>';
	}
	// echo $_SESSION['AdminId'] ;
	 $cid = $_SESSION['AdminId'];
	if(isset($_POST['Submit'])){
		$cpword = md5($_POST['Password']);
		 $sel = "SELECT * FROM bs_admin WHERE Password='$cpword' AND Id=$cid";
		$res  = mysql_query($sel);
		if(mysql_num_rows($res) == 0){
			$ack = "Current password is incorrect";
		}else{
			$npword  = md5($_POST['nPassword']);
			$up = "UPDATE bs_admin SET Password = '$npword' WHERE Id=$cid";
			mysql_query($up);
			$ack = "Password changed successfully";
		}
	}
?>
<?php echo $ack ; ?>
<style>
.mytable{
	padding: 10px;
  width: 600px;
  text-align: left;
	}
	.inpbx{
		  border-radius: 4px;
  height: 31px;
  margin-bottom: 5px;
  font-size: 28px;
  width: 200px;
	}
	.btns{
		height: 38px;
  width: 140px;
  font-size: 16px;
  font-weight: 700;
  border-radius: 4px;
  background: #494949;
	}
		.btns:hover{
		height: 38px;
  width: 140px;
  font-size: 16px;
  font-weight: 700;
  border-radius: 4px;
  background: #AEAEAE;
	}
</style>
	<form name="ChangePassword" method="post" action="">
    <table class="mytable">
    <tr>
    	<td>Current Password</td>
        <td> <input type="password" name="Password" class = "inpbx"></td>
		</tr>
        <tr>
        <td>New Password </td>
  		<td> <input type="password" name="nPassword" class = "inpbx"></td>
		</tr>
		<tr>
        <td>Confirm Password</td>
        <td> <input type="password" name="cPassword" class = "inpbx"></td>
        </tr>
        <tr>
<td><input type="submit" name="Submit" value="Submit" class="btns"></td>
   </tr> </table>
    </form>
<?php
	include_once("Includes/Bottom.php");
?>
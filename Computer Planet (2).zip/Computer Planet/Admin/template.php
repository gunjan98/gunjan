<style type="text/css">
<!--
.head{
	font-size: 14px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #FFFFFF;
	background-color:#FF33CC;
}
a {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #009900;
	font-weight: bold;
}
a:link {
	text-decoration: none;
	color: #99FF00;
}
a:visited {
	text-decoration: none;
	color: #009900;
}
a:hover {
	text-decoration: underline;
	color: #000000;
}
a:active {
	text-decoration: none;
	color: #999999;
}
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #003399;
}
-->
</style>
<table width="100%" border="0" cellspacing="2" cellpadding="0">
  <tr>
    <td height="81" colspan="2" align="right"  class="head">Administrator's Zone<br>
      Restricted Area</td>
  </tr>
  <tr>
    <td width="15%" height="502" valign="top" bgcolor="#FF33CC"><a href="index.php">Home</a><br>
      <a href="Customers.php">Customers</a><br>
      <a href="Categories.php">Categories</a><br>
      <a href="Products.php">Products</a><br>
      <a href="Orders.php">Orders</a><br>
      <a href="MyAccount.php">My Account</a><br>
      <a href="Logout.php">Logout</a></td>
    <td width="85%" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" bgcolor="#009900">&nbsp;</td>
  </tr>
</table>

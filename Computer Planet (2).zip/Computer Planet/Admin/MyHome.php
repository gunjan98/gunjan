<?php
	include_once("Includes/Top.php");
	if($_SESSION['AdminId']=='')
	{
		echo '<script type="text/javascript">window.location.href ="index.php";</script>';
	}
?>
<h1>Welcome to Admin panel</h1>
<?php
	include_once("Includes/Bottom.php");
?>
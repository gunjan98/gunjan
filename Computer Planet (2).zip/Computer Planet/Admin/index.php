	
	<?php
$ack='';
	require_once("../Lib/Config.php");
	if(isset($_POST['Submit'])){
		$aname = $_POST['AdminName'];
		$pwd = md5($_POST['Password']);
		$sel = "SELECT * FROM bs_admin WHERE AdminName='$aname' AND Password='$pwd'";
		$res = mysql_query($sel) or die(mysql_error());
		if(mysql_num_rows($res) == 0){
			$ack = "Admin Name or Password is incorrect";
		}else{
			$rec = mysql_fetch_assoc($res);
			$aid = $rec['Id'];
			$_SESSION['AdminId'] = $aid;
		    header("location: MyHome.php");
		}
	}
?>
<style type="text/css">
<!--
.style3 {
	color: #FFFFFF;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.style10 {color: #009900; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; }
#Layer1 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: 257px;
	top: 115px;
}
-->
</style>
<div id="Layer1">
<div style="color:#FF0000; font-size:12px; font-family:verdana; text-align:center; width: 300px;"><?=$ack?></div>
  <table width="500" border="0" cellspacing="0" cellpadding="3" style="border:brown 0.3em solid">
    <form name="LoginForm" action="" method="post">
      <tr>
        <td height="114" colspan="2" bgcolor="Brown"><span class="style3">Admin Login Panel </span></td>
      </tr>
      <tr>
        <td width="120" height="38"><span class="style10"><font volor=black size=5>Admin Name</font> </span></td>
        <td width="162"><input type="text" name="AdminName"></td>
      </tr>
      <tr>
        <td height="25"><span class="style10"><font volor=black size=3>Password</font></span></td>
        <td><input type="password" name="Password"></td>
      </tr>
      <tr>
        <td colspan="2" align="center"><input type="submit" name="Submit" value="LogIn" style="width:50px"></td>
      </tr>
    </form>
  </table>
<br>
<br>
<br>
<br>
<br>

<font size=3 color=Red>If you are not a Authorized Person Click Back....</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://localhost/Computer%20Planet/index.php"><img src="Images/hh.jpg" width="120" height="100" align=right></a>
<img src="Images/border.gif" width="800" height="350" align=leftt>
</div>

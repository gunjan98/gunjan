<?php

	require_once("../Lib/Config.php");
	if($_SESSION['AdminId']=='')
	{
		echo '<script type="text/javascript">window.location.href ="index.php";</script>';
	}
	$catid = $_GET['catid'];
	$status = $_GET['status'];
	$up = "UPDATE bs_categories SET cStatus=$status WHERE Id=$catid";
	mysql_query($up)or die(mysql_error());
	header("location: Categories.php?ack=Category status has been changed successfully");
?>
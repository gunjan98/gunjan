<?php
	require_once("../Lib/Config.php");
	$oid = $_GET['oid'];
	$status = $_GET['status'];
	$up = "UPDATE bs_orders SET oStatus = $status WHERE Id=$oid";
	mysql_query($up);
	header("Location: Orders.php");
?>
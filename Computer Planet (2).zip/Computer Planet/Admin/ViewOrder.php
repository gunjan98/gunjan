<?php
	include_once("Includes/Top.php");
	$id = $_GET['oid'];
	if($_SESSION['AdminId']=='')
	{
		echo '<script type="text/javascript">window.location.href ="index.php";</script>';
	}
?>
<table width='97%'>
 <tr>
    <th width="13%" class="head">Image</th>
    <th width="18%" class="head">Name</th>
    <th width="13%" class="head">Price</th>
    <th width="16%" class="head">Quantity</th>
    <th width="21%" class="head">Amount</th>	
  </tr>
<?php

		$sel = "SELECT * FROM bs_products p, bs_order_products op WHERE p.Id=op.ProductId AND op.OrderId=$id";
		$res  = mysql_query($sel);
		while($pro = mysql_fetch_assoc($res)){
			$qty = $pro['Quantity'];
			echo "<tr>";
			echo "<td align='center'><img src='../$pro[ImagePath]' width=70 height=70></td>";
			echo "<td>$pro[Name]</td>";
			echo "<td align='right'>Rs. $pro[Price]</td>";
			echo "<td align='center'>$qty</td>";
			$amt  = floatval($pro['Price']) * floatval($qty);
			$netamt +=floatval($amt);
			echo "<td align='right'>Rs. $amt</td>";
			echo "</tr>";
		}

?>
<tr><td colspan="3">&nbsp;</td><td colspan="2" align="right">Total: Rs.<?=floatval($netamt)?></td><td>&nbsp;</td></tr>
</table>
<?php
	include_once("Includes/Bottom.php");
?>
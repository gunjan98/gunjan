<?php
	include_once("Includes/Top.php");
	$sel  = "SELECT o.Id, o.oDate, o.Amount, o.oStatus, c.Name  FROM bs_orders o, bs_customers c WHERE o.CustId=c.Id";
	$res = mysql_query($sel);
?>
<table width="100%" border="0" cellspacing="1" cellpadding="0" align="center">
  <tr>
    <th width="6%" class="head">Id</th>
	<th width="17%" class="head">Name</th>
    <th width="14%" class="head">Date</th>
    <th width="14%" class="head">Amount</th>
    <th width="40%" class="head">Status</th>
    <th width="9%" class="head">View</th>	
  </tr>
 <?php 
 	if(mysql_num_rows($res) == 0){
		echo "<tr><td colspan=5 align=center>No orders placed</td></tr>";
	}
	while($rec = mysql_fetch_assoc($res)){
		switch($rec['oStatus']){
			case 0:
				$pen = "checked";
				$del = "";
				$can = "";
				$prg = "";
				break;
			case 1:
				$pen = "";
				$del = "checked";
				$can = "";
                                $prg = "";
				break;
			case 2:
				$pen = "";
				$del = "";
				$can = "checked";
                                $prg = "";
				break;
                        case 3:
				$pen = "";
				$del = "";
				$can = "";
				$prg = "checked";
				break;	
		}
		$oid = $rec['Id'];
	 echo " <tr>";
	echo"<td>$rec[Id]</td>
		<td>$rec[Name]</td>
		<td>".date("m-d-Y",$rec['oDate'])."</td>
		<td>$rec[Amount]</td>
		<td>";
?>
<input type="radio" name="Status<?=$oid?>" onclick='javascript: location.href="OrderStatus.php?oid=<?=$oid?>&status=0"' <?=$pen?>>Pending
<input type="radio" name="Status<?=$oid?>" onclick='javascript: location.href="OrderStatus.php?oid=<?=$oid?>&status=1"' <?=$del?>>Delivered
<input type="radio" name="Status<?=$oid?>" onclick='javascript: location.href="OrderStatus.php?oid=<?=$oid?>&status=2"' <?=$can?>>Cancelled
<input type="radio" name="Status<?=$oid?>" onclick='javascript: location.href="OrderStatus.php?oid=<?=$oid?>&status=3"' <?=$prg?>>Processing
<?php			
		echo "</td>
		<td><a href='ViewOrder.php?oid=$oid'>View</a></td>
	  </tr>";
  }
 ?> 
</table>
	
<?php
	include_once("Includes/Bottom.php");
?>
<?php
	include_once("Includes/Top.php");
	$cid = $_GET['cid'];
	$sel = "SELECT * FROM bs_products WHERE CatId=$cid";	
	$res = mysql_query($sel);
	if($_SESSION['AdminId']=='')
	{
		echo '<script type="text/javascript">window.location.href ="index.php";</script>';
	}
	
?>
<a href='AddProduct.php?cid=<?=$cid?>'>Add Product</a>
<div style="color: #009966; font-size:14px; font-family:verdana; text-align:center;font-weight: bold;"><?=$_GET['ack']?></div>
<table width="572" cellspacing="2" cellpadding="0" align="center">
  <tr>
        <th width="149" class="head">Name</th>
		<th width="119" class="head">Image</th>
		<th width="79" class="head">Price</th>
		<th width="106" class="head">Status</th>
		<th width="105" class="head">Action</th>		
  </tr>
  <?php
  	if(mysql_num_rows($res) == 0){
		echo "<tr><td colspan=5 align=center>No records found</td></tr>";
	}
	while($rec = mysql_fetch_assoc($res)){
		echo "<tr>";
		echo "<td>$rec[Name]</td>";
		echo "<td><img src='../$rec[ImagePath]' width=70 height=70></td>";
		echo "<td>$rec[Price]</td>";
		echo "<td>";
		if($rec['pStatus'] == 0){
		echo "<a href='ProductStatus.php?cid=$cid&pid=$rec[Id]&status=1'>Activate</a>";
		}else{
		echo "<a href='ProductStatus.php?cid=$cid&pid=$rec[Id]&status=0'>Deactivate</a>";
		}
		echo "</td>";
		echo "<td><a href='EditProduct.php?cid=$cid&pid=$rec[Id]'>Edit</a> | <a href='DeleteProduct.php?cid=$cid&pid=$rec[Id]'>Delete</a></td>";
		echo "</tr>";
	}
  ?>
  <tr>
  </tr>
</table>

<?php
	include_once("Includes/Bottom.php");
?>
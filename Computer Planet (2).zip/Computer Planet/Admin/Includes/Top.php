<?php
	require_once("../Lib/Config.php");
	
?>
<link rel="stylesheet" href="styles.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
<link href="CSS/master.css" rel="stylesheet" />
<table width="100%" border="0" cellspacing="2" cellpadding="0">
  <tr>
    <td height="81" colspan="2" align="middle"  class="head">Administrator's Zone<br><font color=black size=4>RESTRICTED AREA No Unauthorize Person</font></td>
  </tr>
  <tr>
    <td width="15%" height="902" valign="top" bgcolor="cream">   Categories
    <div id='cssmenu'>
<ul>
   <li  class='last'><a href="MyHome.php">Home</a></li>
   <li  class='last'><a href="Customers.php">Customers</a></li>
    <li  class='last'><a href="Categories.php">Categories</a></li>
   <li  class='last'><a href="Orders.php">Orders</a><br></li>
   <li  class='last'> <a href="MyAccount.php">My Account</a><br></li>
   <li  class='last'><a href="Logout.php">Logout</a></li>
</ul></div> 
    </td>
    <td width="85%" valign="top">
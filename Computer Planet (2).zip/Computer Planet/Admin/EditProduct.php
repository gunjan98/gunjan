<?php
	include_once("Includes/Top.php");
	$cid = $_GET['cid'];
	$pid = $_GET['pid'];
	$sel = "SELECT * FROM bs_products WHERE Id=$pid";
	$res = mysql_query($sel);
	$rec = mysql_fetch_assoc($res);

	if(isset($_POST['Submit'])){
		$name = $_POST['Name'];
		$price = $_POST['Price'];
		$desc = $_POST['Description'];

		$tmp = $_FILES['ProImage']['tmp_name'];
		if(is_uploaded_file($tmp)){
			unlink("../".$rec['ImagePath']);
			$orgname = $_FILES['ProImage']['name'];
			$newname = time()."_".$orgname;
			$destpath = "Products/$newname";
			move_uploaded_file($tmp, "../".$destpath);
			$in = "UPDATE bs_products SET Name='$name', Price=$price, ImagePath='$destpath', Description='$desc' WHERE Id=$pid";
		}else{
			$in = "UPDATE bs_products SET Name='$name', Price=$price, Description='$desc' WHERE Id=$pid";
		}
		
		mysql_query($in) or die(mysql_error());
		header("location: Products.php?cid=$cid&ack=Product has been updated successfully");
		
		
	}
	 
?>

<table width="368" border="0" cellspacing="0" cellpadding="2" style="border:#FF3399 0.02em solid" align="center">
<form name="EditProductForm" method="post" action="" enctype="multipart/form-data">
  <tr>
    <th scope="col" class="head" colspan="2">Edit Product</th>
  </tr>
  <tr>
    <td width="103">Name</td>
    <td width="257"><input type="text" name="Name" value="<?=$rec['Name']?>"></td>
  </tr>
  <tr>
    <td>Price</td>
    <td><input type="text" name="Price" value="<?=$rec['Price']?>"></td>
  </tr>
  <tr>
    <td>Image</td> 
    <td><input type="file" name="ProImage"><img src="../<?=$rec['ImagePath']?>" width="40" height="40" /></td>
  </tr>
  <tr>
    <td>Description</td>
    <td><textarea name="Description" rows="3" cols="23"><?=$rec['Description']?></textarea></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="submit" name="Submit" value="Edit" style="width: 90px;"> </td>
  </tr>
  </form>
</table>

<?php
	include_once("Includes/Bottom.php");
?>
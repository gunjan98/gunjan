<?php
	include_once("Includes/Top.php");
	$ack='';
	$cid = $_SESSION['uid'];
	if(isset($_POST['Submit'])){
		$cpword = md5($_POST['Password']);
		$sel = "SELECT * FROM bs_customers WHERE Password='$cpword' AND Id=$cid";
		$res  = mysql_query($sel);
		if(mysql_num_rows($res) == 0){
			$ack = "Current password is incorrect";
		}else{
			$npword  = md5($_POST['nPassword']);
			$up = "UPDATE bs_customers SET Password = '$npword' WHERE Id=$cid";
			mysql_query($up);
			$ack = "Password changed successfully";
		}
	}
?>
<?=$ack?>
	<form name="ChangePassword" method="post" action="">
    <table>
    <tr>
    <td>Current Password</td><td> <input type="password" name="Password" required="required" class="inpbx"></td>
    </tr>
    <tr>
    <td>New Password </td><td>    <input type="password" name="nPassword" required="required" class="inpbx"></td>
    </tr>
    <tr>
    
<td>Confirm Password</td><td> <input type="password" name="cPassword" required="required" class="inpbx"></td>
</tr>
<tr>
<td><input type="submit" name="Submit" value="Submit" required="required" class="btns"></td></tr></table>
    </form>
<?php
	include_once("Includes/Bottom.php");
?>
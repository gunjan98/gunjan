<?php
	include_once("Includes/Top.php");
	$cid = $_GET['cid'];
	$sel_pro = "SELECT * FROM bs_products WHERE CatId=$cid AND pStatus=1 ORDER BY Name";
	$res_pro = mysql_query($sel_pro);
	
?>
<table width="96%" border="0" cellpadding="5" cellspacing="2" align="center">
	<?php
		$cnt = 1;
		if(mysql_num_rows($res_pro) == 0){
			echo "<tr><td align=center colspan=2>No products exists for this category</td></tr>";
		}
		echo "<tr>";
		while($pro = mysql_fetch_assoc($res_pro)){
			echo "<td align=center><a href='ProductInfo.php?pid=$pro[Id]'><img src='$pro[ImagePath]' width=200 height=200 border=0><br>$pro[Name]<br>Rs.  $pro[Price]</td>";
			if($cnt%2 == 0){
				echo "</tr><tr>";
			}
			$cnt++;
		}
		echo "</tr>";
	?>
</table>

<?php
	include_once("Includes/Bottom.php");
?>
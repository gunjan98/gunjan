<?php
	include_once("Includes/Top.php");
?>
<title>Computer PLANET pvt ltd.</title>
<img src="Images/111.jpg" width="1200" height="50" align="center" />
<h1><b>Who we are, what we're about...</b></h1>

<img src="Images/AboutUs1.jpg" width="180" height="300" align=right>

<font color=purpal size=4 face=arial>
Computer PLANET  was built on  the idea that everyone should have access to the best  prices on  computer  products and have a great<br>
selection of parts to choose from regardless of what state or city they lived in. Our goal from the beginning was to deliver the same great<br>
OUTLET prices on PC parts you'd find if you were a distributor or reseller - direct to everyone!  First we partnered with all the major shipping companies to broaden our delivery network to every home, office, and building in the country - meaning that everyone in India could shop<br>
 our store. We also knew early on that this would only work if individuals were allowed to purchase items in any quantity size - meaning that if you only wanted 1 of something, you didn't have to buy 10 to get the savings. So that's what we did.  By keeping operational costs low,<br>
working tirelessly to expand our inventory offerings, optimizing our shipping and sales processes, and by working with distributors and manufacturers to get the best prices of any retailers out there - Computerplanet.com was built to save your money and get you your stuff fast!</font><br>
<br>
<h1><b>How we do it...</b></h1><br>
<font color=purpal size=4 face=arial>We get asked  this question all the time - how do you offer the best prices on the internet on so many computer items, maintain excellent customer service (ResellerRatings Elite 9.0+ Rating), and still ship off over 99%+ of all orders the same business day? The answer to this<br>lies in our caring, dedicated staff of experts who truly want to make your experience the best it can be from every angle - from the price you pay, to how quickly you get your products, to making sure that the products you purchase  are good quality and will last. We believe we have the best staff of any online e-tailer in the computer industry and are out there to prove it to each customer.</font><br><img src="Images/ser3.jpg" width="300" height="350" align=right>
<br>
<h1><b>The Computer PLANET Difference...low prices & great service!</b></h1><br>
<font color=purpal size=4 face=arial>
At Computerplanet.com we take pride in being able to offer you the lowest prices on computer parts and systems...but we also pride ourselves on our customer service and product quality. Being a ResellerRatings.com Elite Excellence award winning website, our customer service standards are set high and all of our employees are trained to resolve issues as quickly as possible.  Call, click, or email your order to us to see the Computer PLANET Difference. We've got the computer parts you need for your next build.
</font><br>
<br>
<h1><b>The Computer PLANET around the Country...
!</b></h1><br>
<font color=purpal size=4 face=arial>
Based on our Hyderabad(H.O),And other six branches in India, From warehouse we ship nationally to over all cities around the country. For a listing of the nearest branches please do visit our Branch locations Page. so, if any problem or query arises you can call easily to nearest branch.</font>

<h1>For Nearest Location..</h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://localhost/Computer%20Planet/Computer%20Planet/location.html"><img src="Images/register.gif" width="180" height="150" /></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<font color=brown size=3 align="center">Email us Right now...</font><a href="http://localhost/Computer%20Planet/Computer%20Planet/ContactUs.php"><img src="Images/email.jpg" width="60" height="80" /></a><br>
<br>

<?php
	include_once("Includes/Bottom.php");
?>

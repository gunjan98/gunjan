<?php
	include_once("Includes/Top.php");
	if(isset($_POST['Submit'])){
		$email  = $_POST['EmailId'];
		$pwd = md5($_POST['Password']);
		$sel = "SELECT * FROM bs_customers WHERE EmailId='$email' AND Password='$pwd'";
		$res = mysql_query($sel);
		if(mysql_num_rows($res) == 0){
			$ack = "No customers exists with this email id";
		}else{
			$rec = mysql_fetch_assoc($res);
			$_SESSION['uid'] = $rec['Id'];
			header("Location: MyHome.php");
		}
	}
?>
<title>Computer PLANET pvt ltd.</title>
<img src="Images/login.jpg" width="300" height="100" align=middle>
<img src="Images/login1.jpg" width="250" height="200" align=right>
<div align="center"><font  Color=green size=5>If you are Registered User</font></div><br>

<form name="LoginForm" method="post" action="" style="text-align:center">
 <font size=4>Email-ID : &nbsp;</font><input type="text" name="EmailId" required="required" class="inpbx" ><br>
<br>
<font size=4>Password : </font><input type="password" name="Password" required="required" class="inpbx"><br>
<br><input type="submit" name="Submit" value="Sign Up!!" align=left class="btns"><br>
<br>
<br>
<br>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<font size=5 color=blue>If you are a new user please....</font><a href="Register.php"><img src="Images/register.png" width="150" height="80" align=right></a></font>
</form><br>
<br>
<br>
<br><div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</div>
<font size=2 color=black>Back to Homepage Click....</font><a href="http://localhost/Computer%20Planet/Computer%20Planet/index.php"><img src="Images/hh.jpg" width="120" height="100" align=middle></a>
<?php
	include_once("Includes/Bottom.php");
?>
<?php
	include_once("Includes/Top.php");
?>
<title>Welcome to Live Projects.</title>
<br>
<font color=green size=5><b>Welcome to Computer PLANET "Live Projects".</b></font><br>
<br>
<img src="Images/ll1.jpg" width="350" height="200" align=right>
<font color=brown size=4>
<b>Live Projects.</b></font><hr width=1000 size=1 color=blue align=left>
<font color=purpal size=4 face=arial>
</br>
Computer PLANET also Provides successful B2B and B2C IT projects. We provide cost-effective custom development solutions using advantages of Microsoft SharePoint, .NET, PHP, Magento Commerce, Joomla! CMS, Linux, JAVA, IBM, Adobe and other platforms and technologies.
Computer PLANET Provides full cycle custom development services from project idea, offshore software development to outsourcing support and maintenance.
<br>
<br>
<font color=brown size=3>
<u>Our Projects advantages are as follows:</u>.</font>
<br><br><img src="Images/middle.gif" width="350" height="200" align=right>
<img src="Images/bb.gif" width="30" height="15"> We Provide Projects for Industries and small scale business in the field of IT,Banking, Retail, Telecom and FMCG<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Fast Moving Consumes Goods).<br><br> 
<img src="Images/bb.gif" width="30" height="15"> We provide the projects which  are developed by professional software developers/managers;<br> <br>
<img src="Images/bb.gif" width="30" height="15"> It suits offshore dedicated service providing model and grants deep intergation with your business processes.<br><br>
<img src="Images/bb.gif" width="30" height="15"> Over 50 successful large/middle projects sold.<br><br>
<img src="Images/bb.gif" width="30" height="15"> Reduced service costs. The prices for our services are relatively lower than in other companies. Dedicated team &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;contracting has lower rates as compared to others.<br>
    <br>
We Provides you assistance in setting up one or several offshore teams depending on your demands. These troops<br>
are carefully selected, well equipped, trained and motivated. For big projects we offer special equipment to use/rent.<br>
We Provides dedicated teams are able to do different tasks, set up by various clients � from small companies to large<br>
enterprises.Computer PLANET provides full-cycle services including analysis,project architecture study,design,project<br>
implementation,support of projects and customers,staffing and retention,data security, management and coordination<br> issues, etc.
Our provided teams of software developers reduces risks and costs of local market entry by 40 - 50%.
<br /><b>For more Info Mail on  <a href="mailto: pinju.kumari@gmail.com ">pinju.kumari@gmail.com </a></b>
<br></br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="mailto: taranjeetkaur1992@gmail.com "><img src="Images/livep.jpg" width="400" height="200" align=center></a>
<br>
<br><br>
<br>
<br>
</font>




<?php
	include_once("Includes/Bottom.php");
?>

<?php
	ob_start();
	session_start();
	define("SITENAME","BeautyShop");
	define('SITETITLE',"BeautyShop::A shop for all beauties");
	define("SITEURL","http://beautyshop.sayasolutions.in");
	define("SENDER_ADDR","info@beautyshop.sayasolutions.in");
	define("SENDERNAME","Web Master");
	define("REGISTRATION_ACK","You have registered successfully. To confirm your email address check the mail");
	
/*	define("HOSTNAME","localhost");
	define("DBUSER","root");
	define("DBPWD","");
	define("DBNAME","beautyshop");	
	
	mysql_connect(HOSTNAME, DBUSER,DBPWD);
	mysql_select_db(DBNAME);*/
	
	mysql_connect("localhost","root","");
	mysql_select_db("complanet");
?>
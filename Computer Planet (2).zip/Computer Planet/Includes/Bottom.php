</td>
  </tr>
  <tr>
    <td height="45" colspan="2" bgcolor="#25A0D7"><div id="footer_bottom" align=center><font color=white size=4>&copy;2016 Computer PLANET pvt ltd, all rights reserved.</font>
</div></td>
    
  </tr>
</table>

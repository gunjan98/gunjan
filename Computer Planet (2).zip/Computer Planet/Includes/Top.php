<?php	
	require_once("Lib/Config.php");
?>
<style type="text/css">
<!--
ul {
	list-style: none;
	margin: 0;
	padding: 0;
	}
#menu {
	width: 200px;
	margin: 2px;
	}
	
#menu li a {
	height: 34px;
  	voice-family: "\"}\""; 
  	voice-family: inherit;
  	height: 24px;
	text-decoration: none;
	}	
	
#menu li a:link, #menu li a:visited {
	color: #FFF;
	display: block;
	background:  url(Includes/menu.gif);
	padding: 8px 0 0 35px;
	}
	
#menu li a:hover {
	color: #FFF;
	background:  url(Includes/menu.gif) 0 -32px;
	padding: 8px 0 0 35px;
	}
	
.style1 {
	color: #FFFFFF;
	font-weight: bold;
	font-size: 14px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.head{
	font-size: 14px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #FFFFFF;
	background-color:#FF33CC;
}

#top a {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #F79F40;
	font-weight: bold;
}
#top a:link {
	text-decoration: none;
	color: #FFF;
}
#top a:visited {
	text-decoration: none;
	color: #FFF;
}
#top a:hover {
	text-decoration: underline;
	color: #FF9933;
}
#top a:active {
	text-decoration: none;
	color: #fff;
}

a {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #F79F40;
	font-weight: bold;
}
a:link {
	text-decoration: none;
	color: #FF00FF;
}
a:visited {
	text-decoration: none;
	color: #FF00FF;
}
a:hover {
	text-decoration: underline;
	color: #CC3300;
}
a:active {
	text-decoration: none;
	color: #25A0D7;
}
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #25A0D7;
}
.mytable{
	padding: 10px;
  width: 600px;
  text-align: left;
	}
	.inpbx{
		  border-radius: 4px;
  height: 31px;
  margin-bottom: 5px;
  font-size: 28px;
  width: 400px;
	}
	.btns{
		height: 38px;
  width: 140px;
  font-size: 16px;
  font-weight: 700;
  border-radius: 4px;
  background: #494949;
	}
		.btns:hover{
		height: 38px;
  width: 140px;
  font-size: 16px;
  font-weight: 700;
  border-radius: 4px;
  background: #AEAEAE;
	}
-->
</style>
<tr>
    <td>&nbsp;</td>
    <td rowspan="2" valign="top"><table width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      
      <tr>
        <td colspan="5"><table width="100%" cellspacing="0" cellpadding="0">
          
          <tr>

<a href="http://localhost/Computer%20Planet/Products.php?cid=32"><img src="Images/tab.jpg" width="150" height="70" /></a>
&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=17"><img src="Images/amd.jpg" width="120" height="70" /></a>
&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/ProductInfo.php?pid=158"><img src="Images/norton.jpg" width="120" height="70" /></a>
&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=20"><img src="Images/fan.jpg" width="100" height="70" /></a>
&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=12"><img src="Images/tabcover.jpg" width="120" height="70" /></a>
&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=18"><img src="Images/dvd.jpg" width="120" height="70" /></a>
&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=34"><img src="Images/headphone.jpg" width="120" height="70" /></a>
</marquee></td>
            <td width="41%"><div align="center" class="text"><font color=blue size=4>DATE :<?php echo date('d/M/Y-(l)') ?></font></td>
            <td width="25%">
			   <div align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://localhost/Computer Planet/admin" class="text"><img src="Images/adminlogin.jpg" width="140" height="40"></a> </div></td>
          </tr>
        </table></td>
      </tr>

<table width="100%" border="0" cellspacing="0" cellpadding="0" style="border: #FF33CC 0.01em solid">

<hr width=1680 size=2 colour=blue align=center>
<img src="Images/97.gif" width="450" height="220">


<tr>
      <td height="45" colspan="2" bgcolor="#25A0D7"><span id="top">&nbsp;&nbsp;&nbsp;<a href="index.php">HOME</a><font color=white size=4> | </font><a href="services.php">SERVICES</a><font color=white size=4> | </font><a href="AboutUs.php">ABOUT US</a><font color=white size=4> | </font><a href="liveproject.php">LIVE PROJECTS</a><font color=white size=4> | </font><a href="ContactUs.php">CONTACT US</a><font color=white size=4> | </font><a href="customercare.php">CUSTOMER SUPPORT</a><font color=white size=4> | </font><a href="register.php">REGISTER FREE</a><font color=white size=4> | </font>
<?php
	if(isset($_SESSION['uid'])){
	echo "<a href='MyAccount.php'>MY ACCOUNT</a><font color=white size=4> | </font><a href='MyOrders.php'>MY ORDERS</a><font color=white size=4> | </font><a href='ShowCart.php'>VIEW CART</a><font color=white size=4> | </font><a href='Logout.php'>LOGOUT</a>";
	}else{
	 echo '<a href="Login.php">ACCOUNT LOGIN</a>';
	 }
?>	
	</span> </td>
	
  </tr>
  <tr>
    <td width="17%" height="360" valign="top">
	<div id='menu'>
	<ul>
	<?php
		$sel_cat = "SELECT * FROM bs_categories WHERE cStatus=1 ORDER BY Name";
		$res_cat = mysql_query($sel_cat);
		while($rec = mysql_fetch_assoc($res_cat)){
			echo "<li><a href='Products.php?cid=$rec[Id]'>$rec[Name]</a></li>";	
		}
	?>
	</ul>
	</div>
	</td>
    <td width="250%" valign ="top" bgcolor="">
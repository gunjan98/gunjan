<?php
	include_once("Includes/Top.php");
?>
<title>Computer PLANET pvt ltd.</title>
<a href='http://localhost/Computer%20Planet/index.php'>
<img src="Images/house.png" width="110" height="98" title='Homepage' align=left></a>
<font color=green size=5>**Hello Guest,Welcome to Computer PLANET.</font>

<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="800" height="700" align=center>
         <param name="movie" value="flash/planet.swf" />
              <param name="quality" value="high" />
         <embed src="flash/planet.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="800" height="380" align=right></embed>

</object><a href="register.php"><img src="Images/think.jpg" width="450" height="350" align="right"></a>

<hr width=1470 size=2 color=blue align=left>

<a href="register.php"><img src="Images/aa1.gif" width="250" height="150" align="left"></a>
<br>
<a href="http://localhost/Computer%20Planet/Products.php?cid=17">
<img src="Images/i5.jpg" width="350" height="300" align="left" title='Processors' align=left></a>&nbsp;
&nbsp;<br>
<br>
<img src="Images/lll.bmp" width="400" height="300" align="left">
&nbsp;
&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=28"><img src="Images/motherboard.jpg" width="400" height="300" align="left" title='Motherboards' align=left></a>
<br>
<br>
<a href="http://localhost/Computer%20Planet/Products.php?cid=16"><img src="Images/laptop.jpg" width="330" height="350" align="left" title='Laptops' align=left></a>
&nbsp;
&nbsp;&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=15"><img src="Images/router.jpg" width="330" height="350" align="left" title='Router' align=left></a>
&nbsp;&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=34"><img src="Images/head.gif" width="250" height="300" align="left" title='Headphone' align=left></a>
&nbsp;&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=37"><img src="Images/pen.jpeg" width="250" height="300" align="left" title='Pendrive' align=left></a>
&nbsp;&nbsp;&nbsp;
<a href="http://localhost/Computer%20Planet/Products.php?cid=35"><img src="Images/external.jpeg" width="250" height="320" align="left" title='External Hardisk' align=left></a>
<br>
<br>
<br>
<br>
<br>
<br>

<?php
	include_once("Includes/Bottom.php");
?>
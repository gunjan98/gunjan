<?php
	include_once("Includes/Top.php");
	$cart = $_SESSION['MyList'];
	$uid  = $_SESSION['uid'];
	$amt = $_SESSION['netamt'];
	$date = time();
	$in_or = "INSERT INTO bs_orders(oDate,Amount, CustId) VALUES('$date', $amt, $uid)";
	mysql_query($in_or);
	$oid = mysql_insert_id();
	foreach($cart as $pid => $qty){
		$in_op = "INSERT INTO bs_order_products VALUES($oid,$pid,$qty)";
		mysql_query($in_op);
	}
	unset($_SESSION['MyList']);
	unset($_SESSION['netamt']);
	echo "Your order has been placed successfully. Your orderid is $oid. We will ship it in 7 business days. Thank you.";
?>

<?php
	include_once("Includes/Bottom.php");
?>
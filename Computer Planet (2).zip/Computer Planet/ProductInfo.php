<?php
	include_once("Includes/Top.php");
	$pid = $_GET['pid'];
	$sel = "SELECT * FROM bs_products WHERE Id=$pid";
	$res = mysql_query($sel);
	$product = mysql_fetch_assoc($res);
	
?>
<table width="96%" border="0" cellspacing="1" cellpadding="2" align="center">
  <tr>
    <td width="22%">Name  </td>
    <td width="45%"><?=$product['Name'];?></td>
    <td width="33%" rowspan="3" align="center"><img src="<?php echo $product['ImagePath']; ?>" width="200" height="200"></td>
  </tr>
  <tr>
    <td>Price</td>
    <td><img src="Images/rupees.jpg" width="12" height="15"><?php echo $product['Price'] ;?></td>
  </tr>
  <tr>
    <td height="115">Description:</td>
    <td rowspan="3" align="justify"><?=nl2br($product['Description'])?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td valign="bottom" align="Left"></td>
  </tr>
  <tr>
  	<td align="left" colspan="2"><a href="AddToCart.php?pid=<?=$pid?>"><img src="Images/buy.png" border="0" /></a></td>
  </tr>
</table>

<?php
	include_once("Includes/Bottom.php");
?>
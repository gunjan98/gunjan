<?php
	include_once("Includes/Top.php");
	$sel  = "SELECT * FROM bs_orders WHERE CustId= $_SESSION[uid]";
	$res = mysql_query($sel);
?>
<table width="80%" border="0" cellspacing="1" cellpadding="2" align="center">
  <tr>
    <th class="head">Order Id</th>
    <th class="head">Date</th>
    <th class="head">Amount</th>
    <th class="head">Status</th>
    <th class="head">View</th>	
  </tr>
 <?php 
 	if(mysql_num_rows($res) == 0){
		echo "<tr><td colspan=5 align=center>No orders placed</td></tr>";
	}
	while($rec = mysql_fetch_assoc($res)){
		switch($rec['oStatus']){
			case 0:
				$status = "Pending";
				break;
			case 1:
				$status = "Delivered";
				break;
			case 2:
				$status = "Cancelled";
				break;
                        case 3:
				$status = "Processing";
				break;		
		}
	 echo " <tr>";
	echo"<td>$rec[Id]</td>
		<td>".date("m-d-Y",$rec['oDate'])."</td>
		<td>$rec[Amount]</td>
		<td>$status</td>
		<td><a href='ViewOrder.php?oid=$rec[Id]'>View</a></td>
	  </tr>";
  }
 ?> 
</table>
	
<?php
	include_once("Includes/Bottom.php");
?>
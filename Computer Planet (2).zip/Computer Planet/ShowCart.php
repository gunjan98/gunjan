<?php
	include_once("Includes/Top.php");
	if(!isset($_SESSION['MyList'])){
		echo "Your cart is empty";
	}else{
	$cart = $_SESSION['MyList'];
	$amt = 0;
	 $netamt = 0;
?>	<table width='97%'>
 <tr>
    <th width="13%" class="head">Image</th>
    <th width="18%" class="head">Name</th>
    <th width="13%" class="head">Price</th>
    <th width="16%" class="head">Quantity</th>
    <th width="21%" class="head">Amount</th>	
    <th width="19%" class="head">Action</th>		
  </tr>
<?php
	foreach($cart as $pid => $qty){
		$sel = "SELECT * FROM bs_products WHERE Id=$pid";
		$res  = mysql_query($sel);
		$pro = mysql_fetch_assoc($res);
		echo "<tr>";
		echo "<td align='center'><img src='$pro[ImagePath]' width=70 height=70></td>";
		echo "<td>$pro[Name]</td>";
		echo "<td align='right'>Rs. $pro[Price]</td>";
		echo "<td align='center'>$qty</td>";
		$amt  = floatval($pro['Price']) * floatval($qty);
		$netamt +=floatval($amt);
		echo "<td align='right'>Rs. $amt</td>";
		echo "<td align='center'><a href='RemoveProduct.php?pid=$pid'>Remove</a></td>";
		echo "</tr>";
	}
	$_SESSION['netamt'] = $netamt;
?>
<tr><td colspan="3">&nbsp;</td><td colspan="2" align="right">Total: Rs.<?=floatval($netamt)?></td><td>&nbsp;</td></tr>
</table>
<a href="CheckOut.php"><img src="Images/checkout.png" border="0" /></a>
<?php
   }
	include_once("Includes/Bottom.php");
?>